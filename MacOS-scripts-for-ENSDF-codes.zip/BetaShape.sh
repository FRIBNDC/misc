#!/bin/zsh
cd /Users/chenj/work/evaluation/ENSDF/tools/BetaShape
cp /Users/chenj/work/evaluation/ENSDF/check/check.tmp /Users/chenj/work/evaluation/ENSDF/tools/BetaShape/BetaShape.ens
/Users/chenj/work/evaluation/ENSDF/tools/BetaShape/betashape BetaShape.ens -asym unc_digit=99 outprec=5
mv BetaShape.new BetaShape.out
echo done>/Users/chenj/work/evaluation/ENSDF/tools/BetaShape/dummy.txt
