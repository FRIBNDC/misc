#!/bin/zsh
cd /Users/chenj/work/evaluation/ENSDF/check
java -jar FormatCheck.jar check.ens
read -s -k $'?Press any key to continue...'
