#!/bin/zsh
cd /Users/chenj/work/evaluation/ENSDF/check
java -jar JAVA_NDS.jar check.ens JAVA_NDS -REFERENCE
read -s -k $'?Press any key to continue...'
