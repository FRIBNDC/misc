#!/bin/zsh
cd /Users/chenj/work/evaluation/ENSDF/check
java -jar BetashapeWrapper.jar /Users/chenj/work/evaluation/ENSDF/check/check.ens -ASYM -ERRORLIMIT=99 -OUTPREC=5
read -s -k $'?Press any key to continue...'