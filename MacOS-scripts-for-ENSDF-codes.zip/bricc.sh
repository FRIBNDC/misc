#!/bin/zsh
cd /Users/chenj/work/evaluation/ENSDF/check
export BrIccHome=/Users/chenj/work/evaluation/ENSDF/check
/Users/chenj/work/evaluation/ENSDF/check/briccMac /Users/chenj/work/evaluation/ENSDF/check/temp.tmp</Users/chenj/work/evaluation/ENSDF/check/bricc_pars.txt
/Users/chenj/work/evaluation/ENSDF/check/briccMac /Users/chenj/work/evaluation/ENSDF/check/temp.tmp MERGE</Users/chenj/work/evaluation/ENSDF/check/bricc_merge_pars.txt
echo done>/Users/chenj/work/evaluation/ENSDF/check/dummy.txt
