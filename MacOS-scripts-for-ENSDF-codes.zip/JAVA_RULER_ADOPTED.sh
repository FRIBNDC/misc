#!/bin/zsh
cd /Users/chenj/work/evaluation/ENSDF/check
java -jar JAVA_RULER.jar check.ens Java_ruler -SHOWLIMIT -ADOPTED
java -jar JAVA_RULER.jar check.ens Java_ruler_show_old -KEEPOLD -SHOWLIMIT -ADOPTED
read -s -k $'?Press any key to continue...'
