#!/bin/zsh
cd /Users/chenj/work/evaluation/ENSDF/check
java -jar Excel2ENSDF.jar check.ens output.xls
read -s -k $'?Press any key to continue...'
