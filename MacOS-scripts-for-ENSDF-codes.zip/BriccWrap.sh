#!/bin/zsh
cd /Users/chenj/work/evaluation/ENSDF/check
java -jar BriccWrapper.jar /Users/chenj/work/evaluation/ENSDF/check/check.ens -ALLSHELLS -ALLGAMMAS -MINCC=0.001 -ASSUMEDMR=1.0
read -s -k $'?Press any key to continue...'
