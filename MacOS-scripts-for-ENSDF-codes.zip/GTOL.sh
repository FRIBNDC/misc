./gtol<./gtol_param.txt
read -n1 -r -p "Press any key to continue..."
