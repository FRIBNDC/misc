#!/bin/zsh
cd /Users/chenj/work/evaluation/ENSDF/check
java -jar GLSC.jar check.ens -NOASSUMED 
read -s -k $'?Press any key to continue...'
