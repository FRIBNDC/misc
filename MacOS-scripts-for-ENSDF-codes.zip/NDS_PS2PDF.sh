ps2pdf /Users/chenj/work/evaluation/ENSDF/check/NDS_output.ps
acroread /Users/chenj/work/evaluation/ENSDF/check/NDS_output.pdf
