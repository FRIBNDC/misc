#!/bin/zsh
cd /Users/chenj/work/evaluation/ENSDF/check
java -jar Excel2ENSDF.jar output.xls output.ens
read -s -k $'?Press any key to continue...'
