#!/bin/zsh
cd /Users/chenj/work/evaluation/ENSDF/check
java -jar KeynumberCheck.jar check.ens -MassChain -useNSRFile
read -s -k $'?Press any key to continue...'
