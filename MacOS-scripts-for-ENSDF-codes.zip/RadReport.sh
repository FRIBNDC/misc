#!/bin/zsh
cd /Users/chenj/work/evaluation/ENSDF/check
java -jar RadiationReport.jar check.ens
read -s -k $'?Press any key to continue...'
