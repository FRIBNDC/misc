java -jar BriccWrapper.jar "H:\work\evaluation\ENSDF\check\check.ens" -ALLSHELLS -ALLGAMMAS -MINCC=0.001 -ASSUMEDMR=1.0 -SUPRATIO
pause