:: java -jar JAVA_NDS.jar "H:\work\evaluation\ENSDF\check\check.ens" JAVA_NDS -REFERENCE -SHOWSUPPRESSED -nsrlogin=login.txt -noredirect -silent
java -Xss4m -jar JAVA_NDS.jar "H:\work\evaluation\ENSDF\check\check.ens" JAVA_NDS -REFERENCE -SHOWSUPPRESSED
pause
