java -jar Excel2ENSDF.jar "H:\work\evaluation\ENSDF\check\output.xls"  "H:\work\evaluation\ENSDF\check\output.ens"
pause
