cd H:\work\evaluation\ENSDF\tools\BetaShape
H:\work\evaluation\ENSDF\tools\BetaShape\betashape.exe H:\work\evaluation\ENSDF\check\check.tmp -asym unc_digit=99 outprec=5
move H:\work\evaluation\ENSDF\check\check.new H:\work\evaluation\ENSDF\tools\BetaShape\BetaShape.out
move H:\work\evaluation\ENSDF\check\check.rpt H:\work\evaluation\ENSDF\tools\BetaShape\BetaShape.rpt
move H:\work\evaluation\ENSDF\check\check.read H:\work\evaluation\ENSDF\tools\BetaShape\BetaShape.read
move H:\work\evaluation\ENSDF\check\check.trans H:\work\evaluation\ENSDF\tools\BetaShape\BetaShape.trans
echo done>H:\work\evaluation\ENSDF\tools\BetaShape\dummy.txt
exit
