java -jar BetashapeWrapper.jar "H:\work\evaluation\ENSDF\check\check.ens" -CLEANONLY
pause