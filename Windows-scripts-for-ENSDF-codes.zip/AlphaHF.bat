java -jar AlphaHF.jar "H:\work\evaluation\ENSDF\check\check.ens"
pause