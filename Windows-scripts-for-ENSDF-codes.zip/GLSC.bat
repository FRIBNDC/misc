java -jar GLSC.jar "H:\work\evaluation\ENSDF\check\check.ens" -NOASSUMED -ERRORLIMIT=35
pause