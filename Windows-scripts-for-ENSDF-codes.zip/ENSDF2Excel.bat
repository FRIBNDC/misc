java -jar Excel2ENSDF.jar "H:\work\evaluation\ENSDF\check\check.ens"  "H:\work\evaluation\ENSDF\check\output.xls" 
pause
