cd H:\work\evaluation\ENSDF\check
set BrIccHome=H:\work\evaluation\ENSDF\check
H:\work\evaluation\ENSDF\check\BrIcc.exe H:\work\evaluation\ENSDF\check\temp.tmp<H:\work\evaluation\ENSDF\check\bricc_pars.txt
H:\work\evaluation\ENSDF\check\BrIcc.exe H:\work\evaluation\ENSDF\check\temp.tmp MERGE<H:\work\evaluation\ENSDF\check\bricc_merge_pars.txt
echo done>H:\work\evaluation\ENSDF\check\dummy.txt
exit
