java -jar FormatCheck.jar "H:\work\evaluation\ENSDF\check\check.ens"
pause