java -jar JAVA_RULER.jar "H:\work\evaluation\ENSDF\check\check.ens" Java_ruler -SHOWLIMIT -ROUNDLIMIT=99
java -jar JAVA_RULER.jar "H:\work\evaluation\ENSDF\check\check.ens" Java_ruler_show_old -KEEPOLD -SHOWLIMIT -ROUNDLIMIT=99
pause