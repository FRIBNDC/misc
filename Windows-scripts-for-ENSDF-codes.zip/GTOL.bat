H:\work\evaluation\ENSDF\check\gtol_win.exe<H:\work\evaluation\ENSDF\check\gtol_param.txt
pause
