java -jar KeynumberCheck.jar "H:\work\evaluation\ENSDF\check\check.ens" -MassChain -useNSRFile
pause