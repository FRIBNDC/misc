java -jar BetashapeWrapper.jar "H:\work\evaluation\ENSDF\check\check.ens" -ASYM -ERRORLIMIT=99 -OUTPREC=5
java -jar BetashapeWrapper.jar "H:\work\evaluation\ENSDF\tools\BetaShape\output.ens" -CLEANONLY
pause